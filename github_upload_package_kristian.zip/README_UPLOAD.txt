UPLOAD GUIDE

1. Upload the folder 'linkedin/kristian/2026-07/' into the public GitHub repo movemarketing/assets.
2. Keep the filenames exactly as they are.
3. After upload, the raw image URLs will match the Metricool CSV.
4. Then import 'metricool_linkedin_kristian_30_posts.csv' into Metricool.

Included files:
- linkedin/kristian/2026-07/*.png  (30 visuals)
- metricool_linkedin_kristian_30_posts.csv
- metricool_github_upload_manifest_kristian_30_posts.csv
